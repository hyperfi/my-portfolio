# Dr Abhishek — A-State Logo Kit

The mark is **`|A⟩`**, drawn as a custom geometric monogram.

- **A** is the initial of Abhishek and the nuclear mass-number symbol.
- **`| ⟩`** is Dirac ket notation, connecting the identity to quantum research.
- The cobalt bar preserves the vertical accent already used throughout the site.
- The construction remains readable at navbar and favicon sizes without using a generic atom icon.

## Files

- `assets/dr-abhishek-mark.svg` — cobalt-only navbar/social mark.
- `assets/dr-abhishek-mark-on-light.svg` — two-colour mark for paper backgrounds.
- `assets/dr-abhishek-mark-on-dark.svg` — two-colour mark for navy backgrounds.
- `assets/dr-abhishek-mark-mono.svg` — monochrome print/accessibility fallback.
- `assets/favicon.svg` — rounded-square browser/app icon.
- `assets/favicon.ico` — 16–64 px legacy browser fallback.
- `assets/logo.png` — 1024 px replacement for the site's current `/images/logo.png`.
- `assets/favicon-512.png` and `assets/favicon-192.png` — PWA/icon sizes.
- `integration/BrandLogo.vue` — responsive Vue 3 navbar component.
- `dr-abhishek-logo-preview.png` — visual identity preview.

## Recommended site integration

1. Copy `assets/favicon.svg` and the PNG sizes into `public/images/`.
2. Replace the current navbar brand markup with `integration/BrandLogo.vue`.
3. Remove the old `.brand::before` rule; the component also overrides it safely.
4. Update the document head:

```html
<link rel="icon" href="/images/favicon.svg" type="image/svg+xml" />
<link rel="icon" href="/images/favicon-192.png" sizes="192x192" type="image/png" />
<link rel="apple-touch-icon" href="/images/favicon-192.png" />
```

The inline Vue mark uses `currentColor` for the letter, so it automatically follows the site's light/dark header colour. Its cobalt strokes use the existing `--accent` token.

## Brand colours

| Role | Hex |
| --- | --- |
| Cobalt | `#304FFE` |
| Cobalt bright (dark surfaces) | `#526BFF` |
| Night | `#11152A` |
| Ink | `#15171A` |
| Paper | `#F2F0E9` |
| Soft white | `#F8F8F4` |
