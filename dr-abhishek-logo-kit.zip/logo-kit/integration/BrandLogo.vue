<template>
  <RouterLink to="/" class="brand brand-logo" aria-label="Dr Abhishek, home">
    <svg
      class="brand-logo__mark"
      viewBox="0 0 128 128"
      aria-hidden="true"
      focusable="false"
    >
      <g fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path class="brand-logo__accent" d="M14 29V99" stroke-width="9" />
        <path d="M31 101 57 27 83 101" stroke="currentColor" stroke-width="9" />
        <path class="brand-logo__accent" d="M42 73H72" stroke-width="9" />
        <path class="brand-logo__accent" d="m98 29 19 35-19 35" stroke-width="9" />
      </g>
    </svg>

    <span class="brand-copy">
      <strong>Dr Abhishek</strong>
      <small>Nuclear physicist</small>
    </span>
  </RouterLink>
</template>

<style scoped>
.brand-logo {
  display: inline-flex;
  align-items: center;
  gap: 0.62rem;
  padding-left: 0;
  color: inherit;
  text-decoration: none;
}

.brand-logo::before {
  content: none;
}

.brand-logo__mark {
  width: 1.95rem;
  height: 1.95rem;
  flex: 0 0 auto;
  overflow: visible;
}

.brand-logo__accent {
  stroke: var(--accent, #304ffe);
}

@media (max-width: 680px) {
  .brand-logo__mark {
    width: 1.75rem;
    height: 1.75rem;
  }
}
</style>
